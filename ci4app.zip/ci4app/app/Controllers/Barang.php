<?php

namespace App\Controllers;

use App\Models\BarangModel;
use CodeIgniter\HTTP\Request;

class Barang extends BaseController
{
    protected $barangModel;
    public function __construct()
    {
        $this->barangModel = new BarangModel();
    }

    //method index
    public function index()
    {

        $currentPage = $this->request->getVar('page_barang') ? $this->request->getVar('page_barang') : 1;

        $keyword = $this->request->getVar('keyword');
        if ($keyword) {
            $tampilBarang = $this->barangModel->search($keyword);
        } else {
            $tampilBarang = $this->barangModel;
        }

        $data = [
            'title' => 'Daftar Barang',
            //'barang' => $this->barangModel->getBarang()
            'barang' => $tampilBarang->paginate(5, 'barang'),
            'pager' => $this->barangModel->pager,
            'currentPage' => $currentPage
        ];

        return view('barang/index', $data);
    }

    //method detail
    public function detail($slug)
    {
        $data = [
            'title' => 'Detail Barang',
            'barang' => $this->barangModel->getBarang($slug)
        ];

        // jika barang tidak ada di tabel
        if (empty($data['barang'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Nama barang ' . $slug . ' Tidak Ditemukan.');
        }

        return view('barang/detail', $data);
    }

    //method create
    public function create()
    {
        //session();
        $data = [
            'title' => 'Form Tambah Data Barang',
            'validation' => \Config\Services::validation()
        ];

        return view('barang/create', $data);
    }

    //method save
    public function save()
    {
        // validasi input
        if (!$this->validate([
            'kode' => [
                'rules' => 'required|is_unique[barang.kode]',
                'errors' => [
                    'required' => '{field} barang harus di isi.',
                    'is_unique' => '{field} barang sudah terdaftar.'
                ]
            ],
            'nama' => [
                'rules' => 'required[barang.nama]',
                'errors' => [
                    'required' => '{field} barang harus di isi.',
                ]
            ],
            'pemilik' => [
                'rules' => 'required[barang.pemilik]',
                'errors' => [
                    'required' => '{field} barang harus di isi.',
                ]
            ],
            'tgl_simpan' => [
                'rules' => 'required[barang.tgl_simpan]',
                'errors' => [
                    'required' => '{field} barang harus di isi.',
                ]
            ],
            'tgl_ambil' => [
                'rules' => 'required[barang.tgl_ambil]',
                'errors' => [
                    'required' => '{field} barang harus di isi.',
                ]
            ],
            'gambar' => [
                'rules' => 'max_size[gambar,1024]|is_image[gambar]|mime_in[gambar,image/jpg,image/jpeg,image/png]',
                'errors' => [
                    'max_size' => 'Ukuran gambar terlalu besar.',
                    'is_image' => 'File yang Anda pilih bukan gambar',
                    'mime_in' => 'File yang Anda pilih bukan gambar'
                ]
            ]
        ])) {
            // $validation = \Config\Services::validation();
            // return redirect()->to('/Barang/create')->withInput()->with('validation', $validation);
            return redirect()->to('/Barang/create')->withInput();
        }

        // ambil Gambar
        $fileGambar = $this->request->getFile('gambar');
        // apakah ada gambar yang diupload ?
        if ($fileGambar->getError() == 4) {
            $namaGambar = 'default.jpg';
        } else {
            // generate nama gambar random
            // $namaGambar = $fileGambar->getRandomName();
            // pindahkan file ke folder img
            $fileGambar->move('img');
            // ambil nama file
            $namaGambar = $fileGambar->getName();
        }

        $slug = url_title($this->request->getVar('nama'), '-', true);
        $this->barangModel->save([
            'nama' => $this->request->getVar('nama'),
            'slug' => $slug,
            'kode' => $this->request->getVar('kode'),
            'gambar' => $namaGambar,
            'pemilik' => $this->request->getVar('pemilik'),
            'tgl_simpan' => $this->request->getVar('tgl_simpan'),
            'tgl_ambil' => $this->request->getVar('tgl_ambil')
        ]);

        session()->setFlashdata('pesan', 'Data Berhasil di Tambahkan.');

        return redirect()->to('/barang');
    }

    //method Delete
    public function delete($id)
    {
        //cari gambar berdasarkan id
        $barang = $this->barangModel->find($id);

        //cek jika file gambar yakni default.jpg
        if ($barang['gambar'] != 'default.jpg') {
            //hapus gambar
            unlink('img/' . $barang['gambar']);
        }

        $this->barangModel->delete($id);
        session()->setFlashdata('pesan', 'Data Berhasil di Hapus.');
        return redirect()->to('/barang');
    }

    //method Edit
    public function edit($slug)
    {
        $data = [
            'title' => 'Form Ubah Data Barang',
            'validation' => \Config\Services::validation(),
            'barang' => $this->barangModel->getBarang($slug)
        ];

        return view('barang/edit', $data);
    }

    //method Update
    public function update($id)
    {
        // cek kode
        $barangLama = $this->barangModel->getBarang($this->request->getVar('slug'));
        if ($barangLama['nama'] == $this->request->getVar('nama')) {
            $ruleJudul = 'required';
        } else {
            $ruleJudul = 'required|is_unique[barang.nama]';
        }

        // validasi input
        if (!$this->validate([
            'nama' => [
                'rules' => $ruleJudul,
                'errors' => [
                    'required' => '{field} barang harus di isi.',
                    'is_unique' => '{field} barang sudah terdaftar.'
                ]
            ],
            'gambar' => [
                'rules' => 'max_size[gambar,1024]|is_image[gambar]|mime_in[gambar,image/jpg,image/jpeg,image/png]',
                'errors' => [
                    'max_size' => 'Ukuran gambar terlalu besar.',
                    'is_image' => 'File yang Anda pilih bukan gambar',
                    'mime_in' => 'File yang Anda pilih bukan gambar'
                ]
            ]
        ])) {
            return redirect()->to('/Barang/edit/' . $this->request->getVar('slug'))->withInput();
        }

        $fileGambar = $this->request->getFile('gambar');

        // cek gambar, apakah tetap sama
        if ($fileGambar->getError() == 4) {
            $namaGambar = $this->request->getVar('gambarLama');
        } else {
            // generate nama file random
            $namaGambar = $fileGambar->getRandomName();
            // pindahkan gambar
            $fileGambar->move('img', $namaGambar);
            // hapus file lama
            unlink('img/' . $this->request->getVar('gambarLama'));
        }

        $slug = url_title($this->request->getVar('nama'), '-', true);
        $this->barangModel->save([
            'id' => $id,
            'nama' => $this->request->getVar('nama'),
            'slug' => $slug,
            'kode' => $this->request->getVar('kode'),
            'gambar' => $namaGambar,
            'pemilik' => $this->request->getVar('pemilik'),
            'tgl_simpan' => $this->request->getVar('tgl_simpan'),
            'tgl_ambil' => $this->request->getVar('tgl_ambil')
        ]);

        session()->setFlashdata('pesan', 'Data Berhasil di Edit.');

        return redirect()->to('/barang');
    }
}
