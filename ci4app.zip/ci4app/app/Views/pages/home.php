<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="ro">
        <div class="col mt-4">
            <h2 class="center">Welcome To Our Website</h2>
            <p class="paragraf mt-4">
                Website ini adalah website untuk penyimpanan barang, dengan adanya website ini maka client dapat menyimpan barang nya kemudian apabila sudah pada deadline penyimpanan maka client dapat mengambilnya kembali.
            </p>
            <p>
                Untuk melakukan penyimpanan maka admin diharuskan untuk <b>Log In</b> terlebih dahulu dengan cara mengklik di atas yakni Log In kemudian diarahkan untuk registrasi kemudian setelah melakukan registrasi maka dapat cek di email yang sudah di daftarkan untuk aktivasi email kemudian admin login setelah itu baru bisa melakukan input barang.
            </p>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>