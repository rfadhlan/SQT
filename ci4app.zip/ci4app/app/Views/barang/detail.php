<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h2 class="mt-2">Detail Barang</h2>
            <div class="card" style="width: 18rem;">
                <img src="/img/<?= $barang['gambar']; ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?= $barang['kode']; ?></h5>
                    <p class="card-text"><?= $barang['nama']; ?></p>
                    <p class="card-text">Pemilik : <?= $barang['pemilik']; ?></p>
                    <p class="card-text">Tanggal Simpan : <?= $barang['tgl_simpan']; ?></p>
                    <p class="card-text">Tanggal Ambil : <?= $barang['tgl_ambil']; ?></p>

                    <a href="/barang/edit/<?= $barang['slug']; ?>" class="btn btn-warning">Edit</a>

                    <form action="/barang/<?= $barang['id']; ?>" method="POST" class="d-inline">
                        <?= csrf_field(); ?>
                        <input type="hidden" name="_method" value="DELETE">
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data Ini ?');">Delete</button>
                    </form>

                    <a href="/barang" class="btn btn-primary">Barang</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>