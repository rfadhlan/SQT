<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-6">
            <h2 class="my-3">Form Ubah Data Barang</h2>

            <form action="/barang/update/<?= $barang['id']; ?>" method="post" enctype="multipart/form-data">
                <?= csrf_field(); ?>
                <input type="hidden" name="slug" value="<?= $barang['slug']; ?>">
                <input type="hidden" name="gambarLama" value="<?= $barang['gambar']; ?>">

                <div class="form-group">
                    <label for="kode">Kode Barang</label>
                    <input type="text" class="form-control <?= ($validation->hasError('kode')) ? 'is-invalid' : ''; ?>" id="kode" name="kode" autofocus value="<?= $barang['kode']; ?>">
                    <div class="invalid-feedback">
                        <?= $validation->getError('kode'); ?>
                    </div>
                </div>

                <div class="form-group">
                    <label for="nama">Nama Barang</label>
                    <input type="text" class="form-control <?= ($validation->hasError('nama')) ? 'is-invalid' : ''; ?>" id="nama" name="nama" value="<?= (old('nama')) ? old('nama') : $barang['nama'] ?>">
                    <div class="invalid-feedback">
                        <?= $validation->getError('nama'); ?>
                    </div>
                </div>

                <div class="form-group">
                    <label for="pemilik">Pemilik</label>
                    <input type="text" class="form-control <?= ($validation->hasError('pemilik')) ? 'is-invalid' : ''; ?>" id="pemilik" name="pemilik" value="<?= (old('pemilik')) ? old('pemilik') : $barang['pemilik'] ?>">
                    <div class="invalid-feedback">
                        <?= $validation->getError('pemilik'); ?>
                    </div>
                </div>

                <div class="form-group">
                    <label for="tgl_simpan">Tanggal Simpan</label>
                    <input type="date" class="form-control <?= ($validation->hasError('tgl_simpan')) ? 'is-invalid' : ''; ?>" id="tgl_simpan" name="tgl_simpan" value="<?= (old('tgl_simpan')) ? old('tgl_simpan') : $barang['tgl_simpan'] ?>">
                    <div class="invalid-feedback">
                        <?= $validation->getError('tgl_simpan'); ?>
                    </div>
                </div>

                <div class="form-group">
                    <label for="tgl_ambil">Tanggal Ambil</label>
                    <input type="date" class="form-control <?= ($validation->hasError('tgl_ambil')) ? 'is-invalid' : ''; ?>" id="tgl_ambil" name="tgl_ambil" value="<?= (old('tgl_ambil')) ? old('tgl_ambil') : $barang['tgl_ambil'] ?>">
                    <div class="invalid-feedback">
                        <?= $validation->getError('tgl_ambil'); ?>
                    </div>
                </div>

                <div class="form-group">
                    <label for="gambar">Gambar</label>
                    <div class="col-sm-4 mb-2">
                        <img src="/img/<?= $barang['gambar']; ?>" class="img-thumbnail img-preview">
                    </div>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input <?= ($validation->hasError('gambar')) ? 'is-invalid' : ''; ?>" id="gambar" name="gambar" onchange="previewImg()">
                        <div class="invalid-feedback">
                            <?= $validation->getError('gambar'); ?>
                        </div>
                        <label class="custom-file-label" for="gambar"><?= $barang['gambar']; ?></label>
                    </div>
                </div>

                <div class="right-button">
                    <button type="submit" class="btn btn-primary">Edit Data</button>
                </div>

            </form>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>