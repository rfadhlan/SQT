<?php

namespace App\Models;

use CodeIgniter\Model;

class BarangModel extends Model
{
    protected $table      = 'barang';
    protected $useTimestamps = true;
    protected $allowedFields = ['kode', 'nama', 'slug', 'gambar', 'pemilik', 'tgl_simpan', 'tgl_ambil'];

    public function getBarang($slug = false)
    {
        if ($slug == false) {
            return $this->findAll();
        }

        return $this->where(['slug' => $slug])->first();
    }

    //method search
    public function search($keyword)
    {
        return $this->table('barang')->like('nama', $keyword)->orLike('kode', $keyword);
    }
}
